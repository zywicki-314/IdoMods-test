const mobMenuToggle = document.querySelector(".mob-menu-toggle");
const mobMenuPopUp = document.querySelector(".mob-items");
const mobMenuItem = document.querySelectorAll(".mob-item");
const descMenuItem = document.querySelectorAll(".nav-item");
const descNavMenu = document.querySelector(".desc-items");
//
const popUpToggle = document.querySelector(".close-pop-up");
const popUpContainer = document.getElementById("popUp");
const blurContainer = document.getElementById("blur");
//
//
const nameId = document.querySelector(".id-data");
const nameText = document.querySelector(".text-data");
//
// POP-UP and BLUR

const blurContainerClose = () => {
  blurContainer.classList.remove("blur-container");
  blurContainer.classList.add("hidden-items");
};
const blurContainerOpen = () => {
  blurContainer.classList.add("blur-container");
  blurContainer.classList.remove("hidden-items");
};

const popUpContainerClose = () => {
  popUpContainer.classList.remove("pop-up");
  popUpContainer.classList.add("hidden-items");
};
const popUpContainerOpen = () => {
  popUpContainer.classList.add("pop-up");
  popUpContainer.classList.remove("hidden-items");
};

popUpToggle.addEventListener("click", function () {
  popUpContainerClose();
  if (blurContainer.classList.contains("blur-container")) {
    blurContainerClose();
  }
});

blurContainer.addEventListener("click", function () {
  blurContainerClose();
  popUpContainerClose();

  if (mobMenuPopUp.classList.contains("mob-nav-active")) {
    mobMenuPopUp.classList.remove("mob-nav-active");
  }
});
//

const mobScreen = document.body.clientWidth < 769;

mobScreen
  ? descNavMenu.classList.add("hidden-items")
  : mobMenuPopUp.classList.add("hidden-items");

// MOB
mobMenuToggle.addEventListener("click", function () {
  const isTheMenuOpen = mobMenuPopUp.classList.contains("mob-nav-active");

  if (isTheMenuOpen) {
    mobMenuPopUp.classList.remove("mob-nav-active");
    blurContainerClose();
  } else {
    mobMenuPopUp.classList.add("mob-nav-active");
    blurContainerOpen();
  }
});

mobMenuItem.forEach((navItem) => {
  navItem.addEventListener("click", function (e) {
    // e.preventDefault();
    mobMenuItem.forEach((navItem) => {
      navItem.classList.contains("mob-item-active")
        ? navItem.classList.remove("mob-item-active")
        : navItem;
    });
    navItem.classList.add("mob-item-active");
    mobMenuPopUp.classList.remove("mob-nav-active");
    blurContainerClose();
  });
});

// SELECT
const apiUrl = "https://brandstestowy.smallhost.pl/api/random";

const selectdata = document.getElementById("produkt-list");
let pageNumber = 1;
let pageSize = selectdata.value;

const fetchData = async () => {
  const url = `${apiUrl}?pageNumber=${pageNumber}&pageSize=${pageSize}`;

  const response = await fetch(url);
  const { data: responseData } = await response.json();

  const loadedData = [];
  for (const key in responseData) {
    loadedData.push({
      id: key,
      text: responseData[key].text,
    });
  }
  displayProducts(loadedData);
};

selectdata.addEventListener("change", function () {
  pageSize = selectdata.value;
  fetchData();
});
//

function displayProducts(products) {
  const productList = document.querySelector(".product-list");

  products.forEach((product) => {
    const productDiv = document.createElement("div");
    productDiv.classList.add("product");

    const productName = document.createElement("h2");
    productName.textContent = product.text;

    productDiv.appendChild(productName);
    productList.appendChild(productDiv);

    productDiv.addEventListener("click", function () {
      blurContainerOpen();
      popUpContainerOpen();

      const id = product.id;
      const text = product.text;

      if (nameId && nameText) {
        nameId.textContent = id;
        nameText.textContent = text;
      }
    });
  });
}

window.addEventListener("scroll", () => {
  if (window.innerHeight + window.scrollY >= document.body.offsetHeight) {
    fetchData();
    pageNumber++;
  }
});
